# AnimatedTriangle

## Screenshot

![screenshot](screenshot/screenshot.gif)

## License Information

Public domain ([CC0](https://creativecommons.org/publicdomain/zero/1.0/))

## Data layout

The following images show the data layout of this sample:

![simpleTriangle](screenshot/simpleTriangle.png)
![animation](screenshot/animation.png)
